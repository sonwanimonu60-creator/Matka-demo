MATKA — Virtual Coin Demo
Open index.html in a browser or upload it to static hosting.
This is a demo using virtual coins only; no real-money deposit, withdrawal, or cash payout.
